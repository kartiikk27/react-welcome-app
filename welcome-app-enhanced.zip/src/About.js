
import React from 'react';

function About() {
  return (
    <div>
      <h2>About This App</h2>
      <p>This is a simple React app with routing and components.</p>
    </div>
  );
}

export default About;
